package com.conexion.basePersona.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Optional;

@RestController
public class ConexionController {

    // Configuración de la conexión
    private static final String URL = "jdbc:mysql://localhost:3306/conectarJava";
    private static final String USER = "root";
    private static final String PASSWORD = "";

    // Método para obtener la conexión
    public static Connection getConnection() throws SQLException {
        try {
            // Carga el controlador JDBC de MySQL
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establece y retorna una conexión a la base de datos utilizando la URL, usuario y contraseña
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (ClassNotFoundException e) {
            // En caso de que no se encuentre el controlador, lanza una excepción SQL con un mensaje de error
            throw new SQLException("Error al cargar el controlador JDBC de MySQL", e);
        }
    }


    @Autowired
    private UsuarioRepository usuarioRepository;
    @PostMapping(value = "/iniciar-sesion", consumes = "application/json")
    public RespuestaDTO iniciarSesion(@RequestBody CredencialesDTO credenciales) {
        Optional<personas> usuarioOptional = usuarioRepository.findByCorreoAndContraseña(credenciales.getUsername(), credenciales.getPassword());

        if (usuarioOptional.isPresent()) {
            return new RespuestaDTO(true, "Inicio de sesión exitoso");
        } else {
            return new RespuestaDTO(false, "Credenciales incorrectas");
        }
    }


    @PostMapping("/registrar-usuario")
    public RespuestaDTO registrarUsuario(@RequestBody UsuarioDTO usuario) {
        try (Connection connection = getConnection()) {
            // Lógica para guardar el usuario en la base de datos

            // Sentencia SQL para insertar un nuevo usuario en la tabla "personas"
            String insertQuery = "INSERT INTO personas (nombre, correo, contraseña) VALUES (?, ?, ?)";

            try (PreparedStatement preparedStatement = connection.prepareStatement(insertQuery)) {
                // Establece los valores de los parámetros en la sentencia SQL
                preparedStatement.setString(1, usuario.getNombre());
                preparedStatement.setString(2, usuario.getCorreo());
                preparedStatement.setString(3, usuario.getContraseña());

                // Ejecuta la sentencia SQL para insertar el nuevo usuario en la base de datos
                preparedStatement.executeUpdate();
            }

            // Retorna una respuesta indicando que el usuario ha sido registrado correctamente
            return new RespuestaDTO("Usuario registrado correctamente");
        } catch (SQLException e) {
            // En caso de error, imprime la traza de la excepción y retorna un mensaje de error
            e.printStackTrace();
            return new RespuestaDTO(false, "Error al registrar usuario: " + e.getMessage());
        }
    }




}
