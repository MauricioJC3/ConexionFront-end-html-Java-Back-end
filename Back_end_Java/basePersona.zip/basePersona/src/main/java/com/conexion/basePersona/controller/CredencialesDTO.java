package com.conexion.basePersona.controller;

public class CredencialesDTO {

        private String username;
        private String password;

        // Constructores, getters y setters según sea necesario

        // Constructor vacío (por defecto)
        public CredencialesDTO() {
        }

        // Constructor con parámetros
        public CredencialesDTO(String username, String password) {
            this.username = username;
            this.password = password;
        }

        // Getter para obtener el nombre de usuario
        public String getUsername() {
            return username;
        }

        // Setter para establecer el nombre de usuario
        public void setUsername(String username) {
            this.username = username;
        }

        // Getter para obtener la contraseña
        public String getPassword() {
            return password;
        }

        // Setter para establecer la contraseña
        public void setPassword(String password) {
            this.password = password;
        }

}
