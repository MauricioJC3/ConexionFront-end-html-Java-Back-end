// RespuestaDTO.java
package com.conexion.basePersona.controller;

public class RespuestaDTO {
    private boolean autenticado;
    private String mensaje;

    // Constructores, getters y setters según sea necesario

    // Constructor con parámetros para establecer el estado de autenticación y el mensaje al crear una instancia
    public RespuestaDTO(boolean autenticado, String mensaje) {
        this.autenticado = autenticado;
        this.mensaje = mensaje;
    }

    // Constructor con parámetro para mensajes de éxito (autenticado=true)
    public RespuestaDTO(String mensaje) {
        this(true, mensaje);
    }

    // Getter para obtener el estado de autenticación
    public boolean isAutenticado() {
        return autenticado;
    }

    // Setter para establecer el estado de autenticación
    public void setAutenticado(boolean autenticado) {
        this.autenticado = autenticado;
    }

    // Getter para obtener el mensaje
    public String getMensaje() {
        return mensaje;
    }

    // Setter para establecer el mensaje
    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }
}

