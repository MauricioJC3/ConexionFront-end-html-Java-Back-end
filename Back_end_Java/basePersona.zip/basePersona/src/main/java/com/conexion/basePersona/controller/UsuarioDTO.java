// UsuarioDTO.java
package com.conexion.basePersona.controller;

public class UsuarioDTO {
    private String nombre;
    private String correo;
    private String contraseña;

    // Constructores, getters y setters según sea necesario

    // Constructor vacío (por defecto)
    public UsuarioDTO() {
    }

    // Constructor con parámetros
    public UsuarioDTO(String nombre, String correo, String contraseña) {
        this.nombre = nombre;
        this.correo = correo;
        this.contraseña = contraseña;
    }

    // Getter para obtener el nombre
    public String getNombre() {
        return nombre;
    }

    // Setter para establecer el nombre
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    // Getter para obtener el correo
    public String getCorreo() {
        return correo;
    }

    // Setter para establecer el correo
    public void setCorreo(String correo) {
        this.correo = correo;
    }

    // Getter para obtener la contraseña
    public String getContraseña() {
        return contraseña;
    }

    // Setter para establecer la contraseña
    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }
}
