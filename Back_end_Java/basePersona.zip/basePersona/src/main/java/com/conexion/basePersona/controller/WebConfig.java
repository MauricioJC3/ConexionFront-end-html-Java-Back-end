package com.conexion.basePersona.controller;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    // Configuración para permitir solicitudes CORS (Cross-Origin Resource Sharing)

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        // Configuración para permitir solicitudes CORS desde cualquier origen y con los métodos especificados
        registry.addMapping("/**")
                .allowedOrigins("*")
                .allowedMethods("GET", "POST", "PUT", "DELETE");
    }
}
