package com.conexion.basePersona;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BasePersonaApplicationTests {

	@Test
	void contextLoads() {
	}

}
